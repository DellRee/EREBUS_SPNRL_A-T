EREBUS Supernatural Equipment - Reference Build
Minecraft Java 26.2 / pack_format 88

Armor texture pass built specifically for EREBUS.

Design direction was informed by the user-provided Thalyrus II and Blades of Majestica reference packs, while the EREBUS textures in this pack are rebuilt as faction-specific variants rather than including those packs' original files.

Vampireite: dark forged metal, crimson accents, restrained brass/gold details.
Wölferite: charcoal/gunmetal, cold blue-gray metal, icy blue accents.
Huntersteel: dark steel, practical hardware, muted teal accents.

The existing EREBUS equipment/item wiring is preserved.
