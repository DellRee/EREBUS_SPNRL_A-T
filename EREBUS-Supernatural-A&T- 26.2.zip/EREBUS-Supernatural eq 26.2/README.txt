EREBUS Supernatural Equipment - ARMOR REDO
Minecraft Java 26.2

Armor layers use the vanilla 64x32 UV layout at 2x resolution (128x64).
Layer 1: helmet, chestplate, arms, boots.
Layer 2: leggings.

Faction visual direction:
- Vampireite: gothic blood-forged armor, crimson veins and dark steel.
- Wolferite: wolf-warrior armor, gunmetal and icy blue.
- Huntersteel: practical reinforced hunter armor, steel, leather and teal.
