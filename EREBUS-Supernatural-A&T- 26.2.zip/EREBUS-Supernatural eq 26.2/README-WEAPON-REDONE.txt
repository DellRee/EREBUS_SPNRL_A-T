EREBUS 26.2 — Weapon Redone Pass

Armor textures were preserved. Weapon textures were redrawn as original pixel art using the supplied Thalyrus II and Blades of Majestica packs only as visual references.

Vampireite: crimson/dark metal with a restrained violet-purple magical accent.
Wolferite: gunmetal/ice-blue with warm amber/bone accents.
Huntersteel: dark steel/teal with brass and leather accents.

No reference-pack files are redistributed in this pack.
